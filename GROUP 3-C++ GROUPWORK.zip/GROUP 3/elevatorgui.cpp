#include "elevatorgui.h"
#include "ui_elevatorgui.h"

int LCDdisplay = 0;

Elevatorgui::Elevatorgui(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Elevatorgui)
{
    ui->setupUi(this);

    ui->LCD->setText(QString::number(LCDdisplay));
    QPushButton *numButtons[10];

    for(int i=10;i<11; i++){
        QString butName = "button" + QString::number(i);
        numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
        connect(numButtons[i], SIGNAL(released()), this,
                SLOT(NumPressed()));
    }
    for(int i=9;i<10; i++){
        QString butName = "button" + QString::number(i);
        numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
        connect(numButtons[i], SIGNAL(released()), this,
            SLOT(NumPressed()));


    }
    for(int i=8; i<9; i++){
        QString butName = "button" + QString::number(i);
        numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
        connect(numButtons[i], SIGNAL(released()), this,
                SLOT(NumPressed()));

    }
    for(int i=7;i<8; i++){
        QString butName = "button" + QString::number(i);
        numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
        connect(numButtons[i], SIGNAL(released()), this,
                SLOT(NumPressed()));
    }
     for(int i=6;i<7; i++){
            QString butName = "button" + QString::number(i);
            numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
            connect(numButtons[i], SIGNAL(released()), this,
                    SLOT(NumPressed()));
     }
     for(int i=5;i<6; i++){
            QString butName = "button" + QString::number(i);
            numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
            connect(numButtons[i], SIGNAL(released()), this,
                    SLOT(NumPressed()));
     }
     for(int i=4;i<5; i++){
            QString butName = "button" + QString::number(i);
            numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
            connect(numButtons[i], SIGNAL(released()), this,
                    SLOT(NumPressed()));
     }
     for(int i=3;i<4; i++){
            QString butName = "button" + QString::number(i);
            numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
            connect(numButtons[i], SIGNAL(released()), this,
                    SLOT(NumPressed()));
     }
     for(int i=2;i<3; i++){
            QString butName = "button" + QString::number(i);
            numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
            connect(numButtons[i], SIGNAL(released()), this,
                    SLOT(NumPressed()));
     }
     for(int i=1;i<2; i++){
            QString butName = "button" + QString::number(i);
            numButtons[i] = Elevatorgui::findChild<QPushButton *>(butName);
            connect(numButtons[i], SIGNAL(released()), this,
                    SLOT(NumPressed()));
     }

}

     Elevatorgui::~Elevatorgui()
{
    delete ui;
};

void Elevatorgui::NumPressed(){
    QPushButton *button = (QPushButton *)sender();
    QString butVal = button ->text();
    QString displayVal = ui->LCD->text();
    if((displayVal.toDouble() == 0)){
        ui->LCD->setText(butVal);
    } else{
        ui->LCD->setText("");
        QString newVal = butVal;
        ui->LCD->setText(newVal);
}

}
