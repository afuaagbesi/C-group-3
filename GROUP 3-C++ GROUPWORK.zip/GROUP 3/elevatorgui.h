
#ifndef ELEVATORGUI_H
#define ELEVATORGUI_H

#include <QMainWindow>



QT_BEGIN_NAMESPACE
namespace Ui { class Elevatorgui; }
QT_END_NAMESPACE

class Elevatorgui : public QMainWindow

{
    Q_OBJECT

public:
    Elevatorgui(QWidget *parent = 0);
    ~Elevatorgui();

private:
    Ui::Elevatorgui *ui;

private slots:
    void NumPressed();
    //void Openpressed();




};


#endif // ELEVATORGUI_H
